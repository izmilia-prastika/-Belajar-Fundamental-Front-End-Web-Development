# Food Pedia
Submission Belajar Fundamental Front-End Web Development Dicoding 2020.
Food Pedia adalah Aplikasi Mesin pencari nama makanan.
API : TheMealDB (https://www.themealdb.com/api.php)